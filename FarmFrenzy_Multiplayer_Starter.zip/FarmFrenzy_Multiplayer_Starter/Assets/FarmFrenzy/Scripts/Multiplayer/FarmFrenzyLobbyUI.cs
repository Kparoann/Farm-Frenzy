using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;

namespace FarmFrenzy.Multiplayer
{
    /// <summary>
    /// Temporary prototype UI. Uses Unity's immediate-mode GUI so the lobby can be tested
    /// before a polished Canvas UI is built.
    /// Host/client connections in this starter are intended for LAN testing.
    /// </summary>
    public sealed class FarmFrenzyLobbyUI : MonoBehaviour
    {
        [SerializeField] private string hostAddress = "127.0.0.1";
        [SerializeField] private ushort port = 7777;
        private string status = "Offline";
        private string playerName = "Farmer";

        private NetworkManager Manager => NetworkManager.Singleton;

        private void OnGUI()
        {
            const int width = 360;
            GUILayout.BeginArea(new Rect(16, 16, width, Screen.height - 32), GUI.skin.box);
            GUILayout.Label("<b>FARM FRENZY SHOWDOWN</b>");
            GUILayout.Space(8);

            if (Manager == null)
            {
                GUILayout.Label("No NetworkManager found in this scene.");
                GUILayout.EndArea();
                return;
            }

            if (!Manager.IsListening)
            {
                GUILayout.Label("Player name (prototype only)");
                playerName = GUILayout.TextField(playerName);
                GUILayout.Label("Host address (for client)");
                hostAddress = GUILayout.TextField(hostAddress);
                GUILayout.Label("Port");
                string portText = GUILayout.TextField(port.ToString());
                if (ushort.TryParse(portText, out ushort parsedPort))
                    port = parsedPort;

                if (GUILayout.Button("Host LAN Match"))
                {
                    UnityTransport transport = Manager.GetComponent<UnityTransport>();
                    if (transport != null)
                        transport.SetConnectionData("127.0.0.1", port, "0.0.0.0");

                    bool started = Manager.StartHost();
                    status = started ? "Hosting on port " + port : "Could not start host. Check Console.";
                }

                if (GUILayout.Button("Join LAN Match"))
                {
                    UnityTransport transport = Manager.GetComponent<UnityTransport>();
                    if (transport != null)
                        transport.SetConnectionData(hostAddress, port);

                    bool started = Manager.StartClient();
                    status = started ? "Connecting to " + hostAddress + ":" + port : "Could not start client. Check Console.";
                }

                GUILayout.Label("For same-PC testing, run one Editor instance as Host and a standalone build as Client.");
                GUILayout.Label("For LAN testing, enter the host computer's local IPv4 address on the client.");
            }
            else
            {
                GUILayout.Label("Connection: " + (Manager.IsHost ? "Host" : Manager.IsServer ? "Server" : "Client"));
                GUILayout.Label("Connected players: " + Manager.ConnectedClientsIds.Count);

                MatchStateMachine match = FindFirstObjectByType<MatchStateMachine>();
                if (match != null)
                {
                    GUILayout.Space(8);
                    GUILayout.Label("Match phase: " + match.CurrentPhase.Value);
                    GUILayout.Label("Ready players: " + match.ReadyCount.Value + " / " + Manager.ConnectedClientsIds.Count);

                    NetworkObject localPlayer = Manager.SpawnManager.GetLocalPlayerObject();
                    if (localPlayer != null)
                    {
                        FarmFrenzyPlayer player = localPlayer.GetComponent<FarmFrenzyPlayer>();
                        if (player != null)
                        {
                            GUILayout.Label("Your ready status: " + (player.IsReady.Value ? "READY" : "NOT READY"));
                            if (match.CurrentPhase.Value == MatchPhase.Lobby &&
                                GUILayout.Button(player.IsReady.Value ? "Cancel Ready" : "Ready Up"))
                            {
                                player.ToggleReadyRpc();
                            }
                        }
                    }

                    if (Manager.IsHost && match.CurrentPhase.Value == MatchPhase.Lobby)
                    {
                        GUI.enabled = match.CanHostStartMatch;
                        if (GUILayout.Button("Start Match (host)"))
                            match.StartMatchRpc();
                        GUI.enabled = true;
                        if (!match.CanHostStartMatch)
                            GUILayout.Label("Need 2+ players and everyone ready.");
                    }
                }

                if (GUILayout.Button("Disconnect"))
                {
                    Manager.Shutdown();
                    status = "Disconnected";
                }
            }

            GUILayout.Space(12);
            GUILayout.Label("Status: " + status);
            GUILayout.EndArea();
        }
    }
}
