using System.Collections;
using Unity.Netcode;
using UnityEngine;

namespace FarmFrenzy.Multiplayer
{
    public enum MatchPhase : byte
    {
        Lobby = 0,
        Countdown = 1,
        Exploration = 2,
        Heist = 3,
        Results = 4
    }

    /// <summary>
    /// Server-authoritative match flow. Put this component and a NetworkObject on a scene
    /// object in the shared FarmMap scene. Keep NGO scene management enabled.
    /// </summary>
    [RequireComponent(typeof(NetworkObject))]
    public sealed class MatchStateMachine : NetworkBehaviour
    {
        public static MatchStateMachine Instance { get; private set; }

        public NetworkVariable<MatchPhase> CurrentPhase = new(
            MatchPhase.Lobby, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        public NetworkVariable<int> ReadyCount = new(
            0, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        public NetworkVariable<int> SecondsRemaining = new(
            0, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        [Header("Prototype round timings")]
        [SerializeField] private int countdownSeconds = 3;
        [SerializeField] private int explorationSeconds = 90;
        [SerializeField] private int heistSeconds = 45;
        [SerializeField] private int resultsSeconds = 10;

        [Header("Spawn points")]
        [SerializeField] private Transform[] spawnPoints;

        public bool CanHostStartMatch =>
            IsServer &&
            CurrentPhase.Value == MatchPhase.Lobby &&
            NetworkManager.Singleton != null &&
            NetworkManager.Singleton.ConnectedClientsIds.Count >= 2 &&
            ReadyCount.Value == NetworkManager.Singleton.ConnectedClientsIds.Count;

        public override void OnNetworkSpawn()
        {
            Instance = this;

            if (IsServer && NetworkManager.Singleton != null)
            {
                NetworkManager.Singleton.OnClientConnectedCallback += OnClientConnected;
                NetworkManager.Singleton.OnClientDisconnectCallback += OnClientDisconnected;
                RefreshReadyCount();
            }
        }

        public override void OnNetworkDespawn()
        {
            if (NetworkManager.Singleton != null && IsServer)
            {
                NetworkManager.Singleton.OnClientConnectedCallback -= OnClientConnected;
                NetworkManager.Singleton.OnClientDisconnectCallback -= OnClientDisconnected;
            }

            if (Instance == this)
                Instance = null;
        }

        private void OnClientConnected(ulong clientId) => RefreshReadyCount();
        private void OnClientDisconnected(ulong clientId) => RefreshReadyCount();

        public void RefreshReadyCount()
        {
            if (!IsServer || NetworkManager.Singleton == null)
                return;

            int ready = 0;
            foreach (ulong clientId in NetworkManager.Singleton.ConnectedClientsIds)
            {
                if (NetworkManager.Singleton.ConnectedClients.TryGetValue(clientId, out var client) &&
                    client.PlayerObject != null &&
                    client.PlayerObject.TryGetComponent(out FarmFrenzyPlayer player) &&
                    player.IsReady.Value)
                {
                    ready++;
                }
            }

            ReadyCount.Value = ready;
        }

        [Rpc(SendTo.Server, RequireOwnership = false)]
        public void StartMatchRpc(RpcParams rpcParams = default)
        {
            // Only the server/host can initiate the match. A remote client cannot call this.
            if (!IsServer || !CanHostStartMatch)
                return;

            ulong sender = rpcParams.Receive.SenderClientId;
            if (sender != NetworkManager.ServerClientId)
                return;

            StartCoroutine(RunMatchFlow());
        }

        private IEnumerator RunMatchFlow()
        {
            if (!IsServer || CurrentPhase.Value != MatchPhase.Lobby)
                yield break;

            SetPhase(MatchPhase.Countdown, countdownSeconds);
            yield return RunTimer(countdownSeconds);

            SetPhase(MatchPhase.Exploration, explorationSeconds);
            yield return RunTimer(explorationSeconds);

            SetPhase(MatchPhase.Heist, heistSeconds);
            yield return RunTimer(heistSeconds);

            SetPhase(MatchPhase.Results, resultsSeconds);
            yield return RunTimer(resultsSeconds);

            // Reset ready state for another prototype round.
            foreach (ulong clientId in NetworkManager.Singleton.ConnectedClientsIds)
            {
                if (NetworkManager.Singleton.ConnectedClients.TryGetValue(clientId, out var client) &&
                    client.PlayerObject != null &&
                    client.PlayerObject.TryGetComponent(out FarmFrenzyPlayer player))
                {
                    player.IsReady.Value = false;
                }
            }

            SetPhase(MatchPhase.Lobby, 0);
            RefreshReadyCount();
        }

        private IEnumerator RunTimer(int duration)
        {
            for (int seconds = duration; seconds > 0; seconds--)
            {
                SecondsRemaining.Value = seconds;
                yield return new WaitForSeconds(1f);
            }

            SecondsRemaining.Value = 0;
        }

        private void SetPhase(MatchPhase phase, int seconds)
        {
            CurrentPhase.Value = phase;
            SecondsRemaining.Value = seconds;
        }

        public void PlacePlayerAtSpawn(FarmFrenzyPlayer player)
        {
            if (!IsServer || player == null)
                return;

            int index = 0;
            if (NetworkManager.Singleton != null)
            {
                foreach (ulong clientId in NetworkManager.Singleton.ConnectedClientsIds)
                {
                    if (NetworkManager.Singleton.ConnectedClients.TryGetValue(clientId, out var client) &&
                        client.PlayerObject != null &&
                        client.PlayerObject.NetworkObjectId == player.NetworkObjectId)
                        break;
                    index++;
                }
            }

            if (spawnPoints != null && spawnPoints.Length > 0)
            {
                Transform spawn = spawnPoints[index % spawnPoints.Length];
                player.transform.SetPositionAndRotation(spawn.position, spawn.rotation);
            }
            else
            {
                // Fallback: arrange players around the origin.
                float angle = index * 45f * Mathf.Deg2Rad;
                Vector3 position = new(Mathf.Cos(angle) * 2.5f, 0f, Mathf.Sin(angle) * 2.5f);
                player.transform.SetPositionAndRotation(position, Quaternion.LookRotation(-position));
            }
        }
    }
}
