using Unity.Netcode;
using UnityEngine;

namespace FarmFrenzy.Multiplayer
{
    /// <summary>
    /// Network player identity/readiness and a simple server-authoritative movement prototype.
    /// Add NetworkObject and NetworkTransform to the Player prefab.
    /// </summary>
    [RequireComponent(typeof(NetworkObject))]
    public sealed class FarmFrenzyPlayer : NetworkBehaviour
    {
        public NetworkVariable<bool> IsReady = new(
            false, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        [Header("Prototype movement")]
        [SerializeField] private float moveSpeed = 5f;
        [SerializeField] private float inputSendInterval = 0.05f;

        private Vector2 pendingInput;
        private float nextInputSendTime;
        private CharacterController characterController;

        public override void OnNetworkSpawn()
        {
            characterController = GetComponent<CharacterController>();

            if (IsServer)
            {
                IsReady.Value = false;
                MatchStateMachine match = FindFirstObjectByType<MatchStateMachine>();
                if (match != null)
                    match.PlacePlayerAtSpawn(this);
            }
        }

        private void Update()
        {
            if (!IsOwner || !IsSpawned)
                return;

            MatchStateMachine match = FindFirstObjectByType<MatchStateMachine>();
            if (match == null || match.CurrentPhase.Value != MatchPhase.Exploration)
                return;

            // Keyboard prototype controls. Replace with Unity Input System actions for release.
            float x = Input.GetAxisRaw("Horizontal");
            float z = Input.GetAxisRaw("Vertical");
            pendingInput = Vector2.ClampMagnitude(new Vector2(x, z), 1f);

            if (Time.unscaledTime >= nextInputSendTime)
            {
                SubmitMovementInputRpc(pendingInput);
                nextInputSendTime = Time.unscaledTime + inputSendInterval;
            }
        }

        private void FixedUpdate()
        {
            if (!IsServer || !IsSpawned)
                return;

            // Server applies validated input; NetworkTransform replicates the resulting position.
            Vector3 direction = new Vector3(serverInput.x, 0f, serverInput.y);
            if (direction.sqrMagnitude > 1f)
                direction.Normalize();

            Vector3 motion = direction * moveSpeed * Time.fixedDeltaTime;
            if (characterController != null && characterController.enabled)
                characterController.Move(motion);
            else
                transform.position += motion;
        }

        private Vector2 serverInput;

        [Rpc(SendTo.Server, RequireOwnership = true)]
        private void SubmitMovementInputRpc(Vector2 input)
        {
            // Basic sanity validation. More advanced speed/teleport checks belong server-side.
            serverInput = Vector2.ClampMagnitude(input, 1f);
        }

        [Rpc(SendTo.Server, RequireOwnership = true)]
        public void ToggleReadyRpc()
        {
            if (!IsServer || !IsSpawned)
                return;

            if (MatchStateMachine.Instance == null ||
                MatchStateMachine.Instance.CurrentPhase.Value != MatchPhase.Lobby)
                return;

            IsReady.Value = !IsReady.Value;
            MatchStateMachine.Instance.RefreshReadyCount();
        }

        public override void OnNetworkDespawn()
        {
            if (IsServer && MatchStateMachine.Instance != null)
                MatchStateMachine.Instance.RefreshReadyCount();
        }
    }
}
