# Farm Frenzy Showdown: Multiplayer Starter

This is a starter code bundle for:
- LAN host/client lobby UI
- Networked player spawning through Netcode for GameObjects (NGO)
- Server-controlled match phases
- Ready-up state
- Basic server-applied movement during Exploration

It is a code starter, not a complete Unity project. Copy the `.cs` files into your Unity project's `Assets/FarmFrenzy/Scripts/Multiplayer/` folder.

## 1. Install packages

In Unity Editor:
1. Open `Window > Package Management > Package Manager`.
2. Install **Netcode for GameObjects** (`com.unity.netcode.gameobjects`).
3. Install **Unity Transport** (`com.unity.transport`) if it was not installed as a dependency.
4. For multi-instance Editor testing, install **Multiplayer Play Mode** if available for your Unity version.

This starter uses NGO's current `[Rpc(SendTo.Server)]` syntax. Use compatible current NGO 2.x packages.

## 2. Create the NetworkManager

In the FarmMap scene:
1. Create an empty GameObject named `NetworkManager`.
2. Add `NetworkManager`.
3. Add `UnityTransport`.
4. In NetworkManager, set Network Transport to the UnityTransport component.
5. Leave Scene Management enabled.
6. Assign the Player prefab after creating it (steps below).
7. Do not enable Connection Approval unless you also configure its callback.

## 3. Create the Player prefab

1. Create a Capsule named `Player`.
2. Add `NetworkObject`.
3. Add `NetworkTransform` (server authoritative/default authority).
4. Add `CharacterController`.
5. Add `FarmFrenzyPlayer`.
6. Make it a prefab by dragging it into `Assets/Prefabs/`.
7. Assign that prefab to `NetworkManager > Player Prefab`.
8. Add the prefab to the Network Prefabs list if your NGO version requires explicit registration.
9. Keep the `NetworkObject` on the prefab root.

The starter controller expects the legacy Unity input axes (`Horizontal`, `Vertical`). If your project uses only the new Input System, set **Active Input Handling** to `Both` in Player Settings for this prototype, or replace the input code with Input System actions. Movement is only active during the Exploration phase.

## 4. Add the match state machine

1. In the FarmMap scene, create an empty GameObject named `MatchStateMachine`.
2. Add `NetworkObject`.
3. Add `MatchStateMachine`.
4. Keep this object in the shared scene. With NGO scene management enabled, an in-scene NetworkObject is synchronized as the scene loads.
5. Optionally create several empty objects around the farm named `SpawnPoint_0`, `SpawnPoint_1`, etc. Assign their Transforms to the `Spawn Points` array on the state machine.

Do not create a separate copy of this manager on each client. It should be one shared in-scene network object.

## 5. Add the temporary lobby UI

1. Create an empty GameObject named `LobbyUI`.
2. Add `FarmFrenzyLobbyUI`.
3. Press Play.
4. Click **Host LAN Match** in one instance.
5. Start a second game instance and enter the host machine's local IPv4 address, then click **Join LAN Match**.
6. Both players click **Ready Up**. The host clicks **Start Match**.

For same-computer testing, use the Editor as host and a standalone build as client. For LAN testing, allow the game through the host computer's firewall if prompted.

## 6. What this match state machine does

`Lobby -> Countdown -> Exploration -> Heist -> Results -> Lobby`

- The server owns the current phase and countdown.
- Clients can read phase and timer values but cannot write them.
- Players ready up through their own PlayerObject.
- Only the host/server can start the match.
- The prototype requires at least two connected players and all players ready.
- The Heist phase is currently a timed phase placeholder. Add the heist UI and resolution logic next.

## Important limitations

- This setup is for local/LAN prototyping. It is **not yet public-internet matchmaking**. For online play across the internet, integrate Unity Relay/Multiplayer Services or deploy a reachable dedicated server.
- Player names are not yet authenticated or persisted.
- The player movement is a minimal prototype, not production-grade anti-cheat or lag compensation.
- Scores, trivia, puzzle rewards, disconnect recovery, server hosting and heist resolution still need to be implemented.
- Before release, move to Unity Input System, test builds on target platforms, and validate NGO APIs against the exact package version installed.

## Troubleshooting

- **No player spawns:** verify the NetworkManager Player Prefab is assigned and has `NetworkObject`; verify the prefab is registered.
- **MatchStateMachine is missing on clients:** make sure the object is in the shared scene, has `NetworkObject`, and NGO scene management is enabled.
- **Client cannot connect:** verify IP and port, both instances use the same protocol/package versions, and the host firewall allows the connection.
- **Ready count does not update:** inspect Console errors and confirm the MatchStateMachine is a spawned NetworkObject.
- **No movement:** confirm the phase is Exploration and the project input setting supports `Input.GetAxisRaw`.

## Official references

- NGO overview: https://docs.unity.com/en-us/multiplayer
- NGO getting started: https://learn.unity.com/tutorial/get-started-with-netcode-for-gameobjects
- Network object spawning: https://github.com/Unity-Technologies/com.unity.multiplayer.docs/blob/main/docs/basics/object-spawning.md
